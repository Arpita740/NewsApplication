package com.example.newsapplication;

import com.example.newsapplication.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
//selectlistener used to handle the events is gui